﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2 : MonoBehaviour
{
    public int HP = 30;

    public int speed = 2;

    void Start()
    {

    }
    void Update()
    {
        if (gameObject.transform.position.y <= -1.7f)
        {
            transform.position += transform.up * speed * Time.deltaTime;
        }
        if (HP <= 0)
        {
            Destroy(gameObject);
            ScoreScript.score += 30;
        }
    }

    void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == "Bullet")
        {
            HP -= 10;
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class pausescript : MonoBehaviour
{
    public static bool GamePaused = false;
    public GameObject PauseUI;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if(GamePaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }
    }
    void Resume()
    {
        PauseUI.SetActive(false);
        Time.timeScale = 1f;
        GamePaused = false;
    }

    void Pause()
    {
        PauseUI.SetActive(true);
        Time.timeScale = 0f;
        GamePaused = true;
    }

    public void menu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(0);
    }
    public void restartlvl1()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(1);
        ScoreScript.score = 0;
    }
    public void restartlvl2()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(2);
        ScoreScript.score = 500;
    }
    public void restartlvl3()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(3);
        ScoreScript.score = 1000;
    }
}



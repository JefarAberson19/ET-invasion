﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    
    public void Play()
    {
        ScoreScript.score = 0;
        SceneManager.LoadScene(1);
        ScoreScript.level1 = true;
        ScoreScript.level2 = false;
        ScoreScript.level3 = false;
    }
    public void Quit()
    {
        Application.Quit();
    }
    public void Menu()
    {
        SceneManager.LoadScene(0);
    }
}

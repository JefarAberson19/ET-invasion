﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy3 : MonoBehaviour
{
    public int HP = 50;

    public int speed = 3;

    void Start()
    {

    }
    void Update()
    {
        if (gameObject.transform.position.y <= -2f)
        {
            transform.position += transform.up * speed * Time.deltaTime;
        }
        if (HP <= 0)
        {
            Destroy(gameObject);
            ScoreScript.score += 50;
        }
    }

    void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == "Bullet")
        {
            HP -= 10;
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour
{
    public GameObject BulletHole;
    public GameObject BulletHole2;
    public GameObject BulletHole3;
    public GameObject Bullet;
    public float bulletForceFoward;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GameObject Temporary_Bullet_Handler;
            Temporary_Bullet_Handler = Instantiate(Bullet, BulletHole.transform.position, BulletHole.transform.rotation) as GameObject;


            Rigidbody Temporary_RigidBody;
            Temporary_RigidBody = Temporary_Bullet_Handler.GetComponent<Rigidbody>();

            Temporary_RigidBody.AddForce(transform.forward * bulletForceFoward);

            Destroy(Temporary_Bullet_Handler, 10.0f);
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GameObject Temporary_Bullet_Handler;
            Temporary_Bullet_Handler = Instantiate(Bullet, BulletHole2.transform.position, BulletHole2.transform.rotation) as GameObject;


            Rigidbody Temporary_RigidBody;
            Temporary_RigidBody = Temporary_Bullet_Handler.GetComponent<Rigidbody>();

            Temporary_RigidBody.AddForce(transform.forward * bulletForceFoward);

            Destroy(Temporary_Bullet_Handler, 10.0f);
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GameObject Temporary_Bullet_Handler;
            Temporary_Bullet_Handler = Instantiate(Bullet, BulletHole3.transform.position, BulletHole3.transform.rotation) as GameObject;


            Rigidbody Temporary_RigidBody;
            Temporary_RigidBody = Temporary_Bullet_Handler.GetComponent<Rigidbody>();

            Temporary_RigidBody.AddForce(transform.forward * bulletForceFoward);

            Destroy(Temporary_Bullet_Handler, 10.0f);
        }
    }
    
}

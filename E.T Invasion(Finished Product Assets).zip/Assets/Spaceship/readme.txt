
Galactic Heroes Cartoon Spaceship
---------------------------------

The package includes:

- 1 Spaceship Model
- 6 Skins
- Diffuse and Specular Materials

If you have any questions or issues please contact us at: unity@funkyfinger.ca

---------------------------------

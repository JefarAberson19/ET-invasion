﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    float nextSpawn = 0.0f;
    float randX;
    Vector3 whereToSpawn;
    public float spawnRate = 2f;
    public GameObject Enemy1;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;
            randX = Random.Range(-4.25f, 4.7f);
            whereToSpawn = new Vector3(randX, transform.position.y, transform.position.z);
            Instantiate(Enemy1,whereToSpawn,Quaternion.Euler(90,0,180));
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreScript : MonoBehaviour
{
    public static int score;
    public Text scoreT;
    public static bool level1;
    public static bool level2;
    public static bool level3;
    // Start is called before the first frame update
    void Start()
    {
        level1 = true;
    }

    // Update is called once per frame
    void Update()
    {
        scoreT.text = "Score: " + score;
        if (score >= 500 && score < 1000 && level2 == false)
        {
            SceneManager.LoadScene(2);
            level2 = true;
            level1 = false;
        }
        else if (score >= 1000  && score < 1500 && level3 == false)
        {
            SceneManager.LoadScene(3);
            level2 = false;
            level1 = false;
            level3 = true;
        }
        else if (score >=1500)
        {
            SceneManager.LoadScene("Win");
            level2 = false;
            level1 = false;
            level3 = false;
        }
    }
}
